/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.suicehehe.demojdbc;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author suice
 */
@WebServlet(name = "demoJDBCServlet", urlPatterns = {"/database"})
public class demoJDBCServlet extends HttpServlet {


    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        
        
            if ("insert".equals(action)) {
                handleInsert(request, response);
            } else if ("update".equals(action)) {
                handleUpdateQuantity(request, response);
            } else if ("delete".equals(action)) {
                handleDeleteById(request, response);
            } else if ("search".equals(action)) {
                handleSearchByName(request, response);
            } else {
                handleGetData(request, response);
            }
    }
    
    
    private void handleInsert(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        ConnectJDBC connectJDBC = new ConnectJDBC();
        Connection conn = connectJDBC.connect();
        
        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        
        Demo demo = new Demo();
        
        demo.insert(conn, id, name, quantity);
        
        handleGetData(request, response);
    }

    
    private void handleUpdateQuantity(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        ConnectJDBC connectJDBC = new ConnectJDBC();
        Connection conn = connectJDBC.connect();
        
        int id = Integer.parseInt(request.getParameter("id"));
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        
        Demo demo = new Demo();
        
        demo.update(conn, id, quantity);
        
        handleGetData(request, response);
    }

    
    private void handleDeleteById(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        ConnectJDBC connectJDBC = new ConnectJDBC();
        Connection conn = connectJDBC.connect();
        
        int id = Integer.parseInt(request.getParameter("id"));
        
        Demo demo = new Demo();
        demo.delete(conn, id);
        
        handleGetData(request, response);
    }
    
    
    private void handleSearchByName(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        ConnectJDBC connectJDBC = new ConnectJDBC();
        Connection conn = connectJDBC.connect();
        
        String name = request.getParameter("name");
        
        
        Demo demo = new Demo();
        List<MyData> dataList = demo.search(conn, name);
        
        request.setAttribute("dataList", dataList);

        String getDatabase = "getDatabase.jsp";
        RequestDispatcher dispatcher = request.getRequestDispatcher(getDatabase);
        dispatcher.forward(request, response);
        
    }

    
    private void handleGetData(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        ConnectJDBC connectJDBC = new ConnectJDBC();
        Connection conn = connectJDBC.connect();

        Demo demo = new Demo();
        List<MyData> dataList = demo.getDataFromDatabase(conn);

        System.out.println(dataList);

        request.setAttribute("dataList", dataList);

        String getDatabase = "getDatabase.jsp";
        RequestDispatcher dispatcher = request.getRequestDispatcher(getDatabase);
        dispatcher.forward(request, response);
    }
}
